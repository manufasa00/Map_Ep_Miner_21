package utility;

/**
 * 
 * Ruolo: modella l'eccezione che occorre qualora si cerca di leggere/cancellare
 * da una coda che e' vuota.
 * 
 * @author manue,ufrack.
 *
 */
public class EmptyQueueException extends Exception {
	/**
	 * Costruttore per l'eccezione di coda vuota.
	 * 
	 * @param msg messaggio da stampare
	 */
	public EmptyQueueException(String msg) {
		super(msg);
	}

}
