package utility;

/**
 * Ruolo: ridefinizione della struttura dati Coda con tipo generico T.
 * 
 * @param <T> parametro generico per la Coda
 * 
 * @author manue,ufrack.
 */
public class Queue<T> {
	/** Record iniziale. */
	private Record begin = null;
	/** Record finale. */
	private Record end = null;

	/**
	 * Inner Class di Queue che modella un elemento di tipo T e un next di tipo
	 * Record.
	 */
	private class Record {
		/** Elemento generico di tipo T del Record. */
		T elem;
		/** Record successivo. */
		Record next;

		/**
		 * Costruttore che alloca e come elemento del Record.
		 * 
		 * @param e elemento di tipo T.
		 */
		Record(T e) {
			this.elem = e;
			this.next = null;
		}
	}

	/**
	 * @return verifica che la coda sia vuota.
	 */
	public boolean isEmpty() {
		return this.begin == null;
	}

	/**
	 * Aggiunge un elemento alla coda.
	 * 
	 * @param e elemento da aggiungere.
	 */
	public void enqueue(T e) {
		if (this.isEmpty())
			this.begin = this.end = new Record(e);
		else {
			this.end.next = new Record(e);
			this.end = this.end.next;
		}
	}

	/**
	 * @return primo elemento della coda.
	 */
	public T first() {
		return this.begin.elem;
	}

	/**
	 * Rimuove un elemento dalla coda.
	 */
	public void dequeue() {
		if (this.begin == this.end) {
			if (this.begin == null)
				System.out.println("The queue is empty!");
			else
				this.begin = this.end = null;
		} else {
			begin = begin.next;
		}

	}

}