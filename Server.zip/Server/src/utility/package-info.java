/**
 * Contiene le classi di utilità generale
 */
package utility;