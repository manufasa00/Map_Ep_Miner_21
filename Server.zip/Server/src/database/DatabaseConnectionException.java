package database;

/**
 * 
 * Ruolo: estende Exception per modellare l'eccezione causata dal database.
 * 
 */
public class DatabaseConnectionException extends Exception {
	/**
	 * Costruttore dell'eccezione per un errore di connessione al db.
	 * 
	 * @param msg messaggio da stampare a video.
	 */
	DatabaseConnectionException(String msg) {
		super(msg);
	}
}
