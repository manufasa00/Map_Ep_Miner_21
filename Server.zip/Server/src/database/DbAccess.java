package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Ruolo: gestisce l'accesso al DB per la lettura dei dati di training.
 * 
 * @author Map Tutor.
 *
 */
public class DbAccess {
	/** Stringa per il ClassName del Driver. */
	private final String DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";
	/** Stringa per il DBMS utilizzato. */
	private final String DBMS = "jdbc:mysql";
	/** Stringa per il nome del Server. */
	private final String SERVER = "localhost";
	/** Stringa per il numero di Porta. */
	private final int PORT = 3306;
	/** Stringa per il ClassName del Driver. */
	private final String DATABASE = "Map";
	/** Stringa per l'id dell'utente. */
	private final String USER_ID = "Student";
	/** Stringa per la password. */
	private final String PASSWORD = "map";
	/** Membro per la connessione al DB. */
	private Connection conn;

	/**
	 * Inizializza una connessione al DB.
	 * 
	 * @throws DatabaseConnectionException possibili errori di connessione al db.
	 */
	public void initConnection() throws DatabaseConnectionException {
		String connectionString = DBMS + "://" + SERVER + ":" + PORT + "/" + DATABASE + "?user=" + USER_ID
				+ "&password=" + PASSWORD + "&serverTimezone=UTC";
		try {

			Class.forName(DRIVER_CLASS_NAME).newInstance();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseConnectionException(e.toString());
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseConnectionException(e.toString());
		} catch (ClassNotFoundException e) {
			System.out.println("Impossibile trovare il Driver: " + DRIVER_CLASS_NAME);
			throw new DatabaseConnectionException(e.toString());
		}

		try {
			conn = DriverManager.getConnection(connectionString, USER_ID, PASSWORD);

		} catch (SQLException e) {
			System.out.println("Impossibile connettersi al DB");
			e.printStackTrace();
			throw new DatabaseConnectionException(e.toString());
		}

	}

	/**
	 * @return connessione conn.
	 */
	public Connection getConnection() {
		return conn;
	}

	/**
	 * chiude la connessione conn.
	 */
	public void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println("Impossibile chiudere la connessione");
		}
	}

}
