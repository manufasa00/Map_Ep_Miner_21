/**
 * Contiene le classi che permettono di interfacciarsi con il Database.
 */
package database;