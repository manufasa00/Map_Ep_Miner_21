package database;

/**
 * Ruolo: Classe enumerativa.
 * 
 * @author Map Tutor.
 *
 */
public enum QUERY_TYPE {
	/**
	 * valore minimo dell'enumerazione.
	 */
	MIN,
	/** valore massimo dell'enumerazione. */
	MAX
}
