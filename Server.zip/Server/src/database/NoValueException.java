package database;

/**
 * 
 * Ruolo: estende Exception per modellare l'assenza di un valore all'interno di
 * un resultset.
 *
 * 
 */
public class NoValueException extends Exception {
	/**
	 * Costruttore dell'eccezione per assenza di un valore.
	 * 
	 * @param msg messaggio da stampare.
	 */
	public NoValueException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
