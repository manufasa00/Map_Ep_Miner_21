package database;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 
 * Ruolo: modella lo schema di una tabella nel database relazionale.
 * 
 */
public class TableSchema {
	/**
	 * Membro per la connessione al DB.
	 */
	private Connection connection;

	/**
	 * Costruttore che inizializza la connessione e imposta la struttura della
	 * tabella.
	 * 
	 * @param tableName  nome della tabella
	 * @param connection connessione al db.
	 * @throws SQLException possibili errori di nomi tabelle.
	 */
	public TableSchema(String tableName, Connection connection) throws SQLException {
		this.connection = connection;
		HashMap<String, String> mapSQL_JAVATypes = new HashMap<String, String>();
		// http://java.sun.com/j2se/1.3/docs/guide/jdbc/getstart/mapping.html
		mapSQL_JAVATypes.put("CHAR", "string");
		mapSQL_JAVATypes.put("VARCHAR", "string");
		mapSQL_JAVATypes.put("LONGVARCHAR", "string");
		mapSQL_JAVATypes.put("BIT", "string");
		mapSQL_JAVATypes.put("SHORT", "number");
		mapSQL_JAVATypes.put("INT", "number");
		mapSQL_JAVATypes.put("LONG", "number");
		mapSQL_JAVATypes.put("FLOAT", "number");
		mapSQL_JAVATypes.put("DOUBLE", "number");

		DatabaseMetaData meta = connection.getMetaData();
		ResultSet res = meta.getColumns(null, null, tableName, null);

		while (res.next()) {

			if (mapSQL_JAVATypes.containsKey(res.getString("TYPE_NAME")))
				tableSchema.add(
						new Column(res.getString("COLUMN_NAME"), mapSQL_JAVATypes.get(res.getString("TYPE_NAME"))));

		}
		res.close();

	}

	/**
	 * Ruolo: Inner Class privata per modellare la generica colonna all'interno di
	 * uno schema.
	 * 
	 * @author Map Tutor.
	 *
	 */
	public class Column {
		/** Stringa per il nome della colonna. */
		private String name;
		/** Stringa per il tipo della colonna. */
		private String type;

		/**
		 * Costruttore che inizializza i membri name e type.
		 * 
		 * @param name nome della colonna
		 * @param type tipo della colonna.
		 */
		Column(String name, String type) {
			this.name = name;
			this.type = type;
		}

		/**
		 * 
		 * @return nome della colonna.
		 */
		public String getColumnName() {
			return name;
		}

		/**
		 * 
		 * @return booleano che indica se il tipo e' uguale a 'number'.
		 */
		public boolean isNumber() {
			return type.equals("number");
		}

		@Override
		public String toString() {
			return name + ":" + type;
		}
	}

	/**
	 * Tabelle del Database rappresentate come ArrayList di Column.
	 */
	List<Column> tableSchema = new ArrayList<Column>();

	/**
	 * 
	 * @return dimensione dello schema.
	 */
	public int getNumberOfAttributes() {
		return tableSchema.size();
	}

	/**
	 * 
	 * @param index indice della colonna
	 * @return la colonna con indice index.
	 */
	public Column getColumn(int index) {
		return tableSchema.get(index);
	}

}
