package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 
 * Ruolo: modella un server in grado di accettare la richiesta trasmesse da un
 * generico Client e istanzia un oggetto della classe ServerOneClient che si
 * occupera di servire le richieste del client in un thred dedicato. Il Server
 * sarà registrato su una porta predefinita (al di fuori del range 1-1024), per
 * esempio 8080.
 * 
 * @author manue,ufrack.
 *
 */
public class MultiServer {
	/**
	 * Costante finale di tipo int che indica il numero della porta inizializzata a
	 * 8080.
	 */
	public static final int PORT = 8080;

	/**
	 * crea un oggetto istanza di MultiServer.
	 * 
	 * @param args argomenti del main.
	 * 
	 * @throws IOException possibili errori di Input\Output.
	 */
	public static void main(String[] args) throws IOException {
		MultiServer s = new MultiServer();

	}

	/**
	 * invoca il metodo privato run.
	 * 
	 * @throws IOException possibili errori di Input\Output.
	 */
	MultiServer() throws IOException {
		run();
	}

	/**
	 * assegna ad una variabile locale s il riferimento ad una istanza della classe
	 * ServerSocket creata usando la porta PORT. s si pone in attesa di richieste di
	 * connessione da parte di client in risposta alle quali viene restituito
	 * l’oggetto Socket da passare come argomento al costruttore della classe
	 * ServerOneClient.
	 * 
	 * @throws IOException possibili errori di Input\Output.
	 */
	private void run() throws IOException {
		ServerSocket s = new ServerSocket(PORT);
		System.out.println("Server avviato");
		try {
			while (true) {
				// System.out.println("In attesa di connessione...");
				Socket socket = s.accept();
				try {
					System.out.println("Connessione di: " + socket.toString());
					new ServerOneClient(socket);
				} catch (IOException e) {// Se fallisce chiude il socket,
					// altrimenti il thread la chiuderà:
					System.out.println("closing...");
					socket.close();
				}
			}
		} finally {
			s.close();// ServerSocket
		}
	}

}
