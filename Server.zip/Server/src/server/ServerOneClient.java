package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;

import data.Data;
import data.EmptySetException;
import database.DatabaseConnectionException;
import database.NoValueException;
import mining.EmergingPatternMiner;
import mining.FrequentPatternMiner;
import utility.EmptyQueueException;

/**
 * 
 * Ruolo: estende la classe Thread che modella la comunicazione con un unico
 * client.
 * 
 * @author manue,ufrack.
 *
 */
public class ServerOneClient extends Thread {
	/** Socket per la connessione al Server. */
	private Socket socket;
	/** Oggetto per l'input dello stream. */
	private ObjectInputStream in;
	/** Oggetto per l'output dello stream. */
	private ObjectOutputStream out;

	/**
	 * Costruttore. Inizializza il membro this.socket con il parametro in input al
	 * costruttore. Inizializza in e out, avvia il thread invocando il metodo
	 * start() (ereditato da Thread).
	 * 
	 * @param s Socket da assegnare al membro attributo.
	 * @throws IOException possibili errori di Input/Output.
	 */
	public ServerOneClient(Socket s) throws IOException {
		socket = s;
		in = new ObjectInputStream(s.getInputStream());
		out = new ObjectOutputStream(socket.getOutputStream());
		System.out.println("Nuovo client connesso");
		start();
	}

	/**
	 * Ridefinisce il metodo run della classe Thread (variazione funzionale).
	 * Gestisce le richieste del client(apprendere pattern/regole).
	 */
	public void run() {
		try {
			while (true) {
				process();
			}
		} catch (IOException e) {
			System.out.println("Client disconnesso!");
		} catch (ClassNotFoundException e) {
			System.err.println("Class Not Found Exception");
		} catch (DatabaseConnectionException e) {
			e.printStackTrace();
		} catch (NoValueException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				System.err.println("Socket not closed");
			}
		}
	}

	/**
	 * si occupa delle nuove scoperte e del salvataggio e del caricamento di una
	 * scoperta in archivio.
	 * 
	 * @throws IOException                 possibili errori di Input\Output
	 * @throws ClassNotFoundException      possibili errori di classe non trovata
	 * @throws DatabaseConnectionException possibili errori di connessione al db
	 * @throws NoValueException            possibili errori di valori assenti.
	 */
	public void process() throws IOException, ClassNotFoundException, DatabaseConnectionException, NoValueException {
		int opzione = (int) in.readObject();
		float minsup = (float) in.readObject();
		float minGr = (float) in.readObject();
		String target = (String) in.readObject();
		String background = (String) in.readObject();
		boolean pass = true; // variabile che se vale false dà errore in entrambe le tabelle
		if (opzione == 1) {
			try {
				FrequentPatternMiner fpMiner = null;
				try {
					Data dataTarget = new Data(target);
					fpMiner = new FrequentPatternMiner(dataTarget, minsup);
					try {
						fpMiner.salva("FP_playtennis_minSup" + minsup + "_t_" + target + ".dat");
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					out.writeObject(fpMiner.toString());
				} catch (SQLException sqe) {
					out.writeObject("Errore");
					pass = false;
				}
				if (pass) {

					try {
						Data dataBackground = new Data(background);
						try {
							EmergingPatternMiner epMiner = new EmergingPatternMiner(dataBackground, fpMiner, minGr);
							try {
								epMiner.salva("EP_playtennis_minSup" + minsup + "_minGr" + minGr + "_t_" + target
										+ "_b_" + background + ".dat");
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							out.writeObject(epMiner.toString());
						} catch (EmptySetException e) {
							e.printStackTrace();
						}
					} catch (SQLException sqe) {
						out.writeObject("Errore");
					} catch (NullPointerException e) {
						e.printStackTrace();
					}
				} else {
					out.writeObject("Errore");
				}
			} catch (EmptySetException e) {
				e.printStackTrace();
			} catch (EmptyQueueException e2) {
				e2.printStackTrace();
			}
		} else {

			try {
				FrequentPatternMiner fpMiner = FrequentPatternMiner
						.carica("FP_playtennis_minSup" + minsup + "_t_" + target + ".dat");
				out.writeObject(fpMiner.toString());
			} catch (ClassNotFoundException | IOException e) {
				out.writeObject("File FrequentPattern con " + "minsup = " + minsup + " non trovato in archivio");

			}
			try {
				EmergingPatternMiner epMiner = EmergingPatternMiner.carica("EP_playtennis_minSup" + minsup + "_minGr"
						+ minGr + "_t_" + target + "_b_" + background + ".dat");
				out.writeObject(epMiner.toString());
			} catch (ClassNotFoundException | IOException e) {
				out.writeObject("File EmergingPattern con " + "minsup = " + minsup + " minGr = " + minGr
						+ " non trovato in archivio");

			}

		}

	}

}
