package data;

import java.util.Iterator;

/**
 * 
 * Ruolo: implementa l'interfaccia Iterator. Tale classe realizza l’iteratore
 * che itera sugli elementi della sequenza composta da numValues valori reali
 * equidistanti tra di loro (cut points) compresi tra min e max ottenuti per
 * mezzo di discretizzazione. La classe implementa i metodi della interfaccia
 * generica Iterator tipizzata con Float.
 * 
 * @author manue,ufrack.
 *
 */
public class ContinuousAttributeIterator implements Iterator<Float> {
	/** minimo dell'intervallo. */
	private float min;
	/** massimo dell'intervallo. */
	private float max;
	/** contatore per i cut point. */
	private int j = 0;
	/** numero di intervalli di discretizzazione. */
	private int numValues;

	/**
	 * Avvalora i membri attributo della classe con i parametri del costruttore.
	 * 
	 * @param min       minimo dell'intervallo
	 * @param max       massimo dell'intervallo
	 * @param numValues numero di intervalli di discretizzazione.
	 */
	ContinuousAttributeIterator(float min, float max, int numValues) {
		this.min = min;
		this.max = max;
		this.numValues = numValues;
	}

	/**
	 * @return true se j e' minore o uguale di numValues, false altrimenti.
	 */
	public boolean hasNext() {
		return (j <= numValues);
	}

	/**
	 * Incrementa j, restituisce il cut point in posizione j-1 (min +
	 * (j-1)*(max-min)/numValues).
	 */
	public Float next() {
		j++;
		return min + ((max - min) / numValues) * (j - 1);
	}

	@Override
	public void remove() {

	}

}
