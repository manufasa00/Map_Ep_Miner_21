package data;

import java.io.Serializable;
import java.util.Iterator;

/**
 * 
 * Ruolo: estende la classe Attribute e modella un attributo continuo (numerico)
 * rappresentandone il dominio [min,max].
 * 
 * @author manue,ufrack.
 *
 */
public class ContinuousAttribute extends Attribute implements Iterable<Float>, Serializable {
	/**
	 * massimo dell'attributo.
	 */
	private float max;
	/**
	 * minimo dell'attributo.
	 */
	private float min;

	/**
	 * Invoca il costruttore della classe madre e avvalora i membri.
	 * 
	 * @param name  nome dell’attributo
	 * @param index identificativo numerico dell'attributo
	 * @param min   minimo dell'intervallo di dominio
	 * @param max   massimo dell'intervallo di dominio
	 */
	ContinuousAttribute(String name, int index, float min, float max) {
		super(name, index);
		this.max = max;
		this.min = min;
	}

	/**
	 * Restituisce il valore del membro min.
	 * 
	 * @return estremo inferiore dell'intervallo.
	 */
	public float getMin() {
		return min;
	}

	/**
	 * Restituisce il valore del membro max.
	 * 
	 * @return estremo superiore dell'intervallo.
	 * 
	 */
	public float getMax() {
		return max;
	}

	/**
	 * Istanzia e restituisce un riferimento ad oggetto di classe
	 * ContinuousAttributeIterator con numero di intervalli di discretizzazione pari
	 * a 5.
	 * 
	 * @return riferimento a una istanza di ContinuousAttributeIterator.
	 * 
	 */
	public Iterator<Float> iterator() {
		return new ContinuousAttributeIterator(min, max, 5);
	}

}
