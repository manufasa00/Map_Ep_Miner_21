package data;

import java.io.Serializable;

/**
 * 
 * Ruolo: estende la classe Attribute e modella un attributo discreto
 * rappresentando l'insieme di valori distinti del relativo dominio.
 * 
 * @author manue,ufrack.
 *
 */
public class DiscreteAttribute extends Attribute implements Serializable {
	/**
	 * Array di stringhe per contenere i valori degli attributi discreti.
	 */
	private String values[];

	/**
	 * Invoca il costruttore della classe madre e avvalora l'array values[] con i
	 * valori discreti in input.
	 * 
	 * @param name   nome simbolico dell'attributo
	 * @param index  identificativo numerico dell'attributo
	 * @param values valori discreti che ne costituiscono il dominio.
	 */
	DiscreteAttribute(String name, int index, String values[]) {
		super(name, index);
		this.values = new String[values.length];
		System.arraycopy(values, 0, this.values, 0, values.length);
	}

	/**
	 * Restituisce la cardinalità del membro values.
	 * 
	 * @return numero di valori discreti dell'attributo.
	 */
	public int getNumberOfDistinctValues() {
		return values.length;
	}

	/**
	 * Restituisce il valore in posizione i del membro values.
	 * 
	 * @param index indice di tipo intero.
	 * @return restituisce un valore nel dominio dell’attributo.
	 */
	public String getValue(int index) {
		return values[index];
	}

}
