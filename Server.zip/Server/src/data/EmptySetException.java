package data;

/**
 * 
 * Ruolo: modella l'eccezione che occorre qualora l'insieme di training fosse
 * vuoto (non contiene transazioni/esempi). Tale eccezione e' sollevata nei
 * costruttori di FrequentPatternMiner e EmergingPatternMiner ed e' gestita in
 * MainTest.
 * 
 * @author manue,ufrack.
 *
 */
public class EmptySetException extends Exception {
	/**
	 * Costruttore dell'eccezione per l'insieme vuoto.
	 * 
	 * @param msg messaggio da stampare.
	 */
	public EmptySetException(String msg) {
		super(msg);
	};

}
