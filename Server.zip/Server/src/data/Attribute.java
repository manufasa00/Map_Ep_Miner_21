package data;

import java.io.Serializable;

/**
 * 
 * Ruolo: modella un generico attributo discreto o continuo.
 * 
 * @author manue,ufrack.
 *
 */
public abstract class Attribute implements Serializable {
	// attributi
	/**
	 * nome dell'attributo.
	 */
	private String name;
	/**
	 * indice dell'attributo.
	 */
	private int index;

	/**
	 * Inizializza i valori dei membri name, index.
	 * 
	 * @param name  nome simbolico dell'attributo
	 * @param index identificativo numerico
	 */
	Attribute(String name, int index) {
		this.name = name;
		this.index = index;
	}

	/**
	 * Restituisce il valore nel membro name.
	 * 
	 * @return nome dell'attributo
	 */
	public String getName() {
		return name;
	}

	/**
	 * Restituisce il valore nel membro index.
	 * 
	 * @return identificativo numerico dell'attributo.
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * Restituisce il valore del membro name.
	 * 
	 * @return identificativo.
	 */
	public String toString() {
		return name;
	}
}
