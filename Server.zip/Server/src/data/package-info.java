/**
 * Contiene le classi che modellano i vari tipi di un attributo.
 */
package data;