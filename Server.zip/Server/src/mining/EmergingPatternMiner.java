package mining;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

import data.Data;
import data.EmptySetException;

/**
 * 
 * Ruolo: modella la scoperta di emerging pattern partire dalla lista di
 * frequent pattern.
 * 
 * @author manue,ufrack.
 *
 */
public class EmergingPatternMiner implements Iterable<EmergingPattern>, Serializable {
	/**
	 * Lista dei pattern emergenti rappresentata come una LinkedList di
	 * EmergingPattern.
	 */
	private LinkedList<EmergingPattern> epList = new LinkedList<EmergingPattern>();

	/**
	 * Si scandiscono tutti i frequent pattern in fpList , per ognuno di essi si
	 * calcola il grow rate usando dataBackground e se tale valore e' maggiore
	 * uguale di minG allora il pattern e' aggiunto ad epList facendo uso del metodo
	 * computeEmergingPattern.
	 * 
	 * @param dataBackground il dataset di background su cui calcolare il growrate
	 *                       di tutti i pattern presenti in fpList considerando con
	 *                       minimo grow rate minG
	 * @param fpList         lista di pattern
	 * @param minG           minimo valore di grow rate.
	 * @throws EmptySetException possibili errori di insieme vuoto.
	 */
	public EmergingPatternMiner(Data dataBackground, FrequentPatternMiner fpList, float minG) throws EmptySetException {
		try {
			Iterator<FrequentPattern> e = fpList.iterator();

			while (e.hasNext()) {
				FrequentPattern fp = e.next();
				try {
					if (computeEmergingPattern(dataBackground, fp, minG) != null) {
						epList.add(computeEmergingPattern(dataBackground, fp, minG));
					}
				} catch (EmergingPatternException ex) {
					// TODO Auto-generated catch block
					ex.printStackTrace();
				}
			}
			sort();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Si ottiene da fp il suo supporto relativo al dataset target. Si calcola il
	 * supporto di fp relativo al dataset di background. Si calcola il grow rate
	 * come rapporto dei due supporti.
	 * 
	 * @param dataBackground l’insieme delle transazioni di background
	 * @param fp             pattern frequente di cui calcolare il growrate
	 * @return grow rate di fp.
	 * 
	 */
	float computeGrowRate(Data dataBackground, FrequentPattern fp) {
		return fp.getSupport() / fp.computeSupport(dataBackground);
	}

	/**
	 * Verifica che il grow rate di fp sia maggiore di minGR. In caso affermativo
	 * crea un oggetto EmemrgingPattern da fp.
	 * 
	 * @param dataBackground insieme di transazioni di background
	 * @param fp             frequent pattern
	 * @param minGR          minimo grow rate
	 * @return l'emerging pattern creato da fp se la condizione sul grow rate e'
	 *         soddisfatta, null altrimenti.
	 * @throws EmergingPatternException possibili errori di condizioni non
	 *                                  sufficienti per EmergingPattern.
	 */
	EmergingPattern computeEmergingPattern(Data dataBackground, FrequentPattern fp, float minGR)
			throws EmergingPatternException {
		float growrate = computeGrowRate(dataBackground, fp);
		if (growrate >= minGR) {
			EmergingPattern ep = new EmergingPattern(fp, growrate);
			return ep;
		} else {
			return null;
		}
	}

	/**
	 * Scandisce epList al fine di concatenare in un'unica stringa le stringhe
	 * rappresentati i pattern emergenti letti.
	 * 
	 * @return Stringa rappresentante il valore di epList.
	 */
	public String toString() {
		String value = "Emerging patterns\n";
		int i = 0;
		Iterator<EmergingPattern> e = epList.iterator();
		while (e.hasNext()) {
			value += Integer.toString(i + 1) + ": " + e.next() + "\n";
			i++;
		}
		return value;
	}

	@Override
	public Iterator<EmergingPattern> iterator() {
		Iterator<EmergingPattern> iep = epList.iterator();
		return iep;
	}

	/**
	 * si occupa di ordinare epList usando il comparatore associato alla classe
	 * EmergingPattern.
	 */
	private void sort() {
		Collections.sort(epList, new ComparatorGrowRate());

	}

	/**
	 * si occupa di serializzare l’oggetto riferito da this nel file il cui nome e'
	 * passato come parametro.
	 * 
	 * @param nomeFile nome del file in cui avviene la serializzazione.
	 * @throws FileNotFoundException possibili errori di file non trovato
	 * @throws IOException           possibili errori di Input\Output.
	 */
	public void salva(String nomeFile) throws FileNotFoundException, IOException {
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nomeFile));
		out.writeObject(this);
		out.close();
	}

	/**
	 * si occupa di leggere e restituire l’oggetto come e' memorizzato nel file il
	 * cui nome e' passato come parametro.
	 * 
	 * @param nomeFile nome del file da cui viene caricato l'oggetto.
	 * @throws FileNotFoundException  possibili errori di file non trovato.
	 * @throws IOException            possibili errori di Input/Output
	 * @throws ClassNotFoundException possibili errori di classe non trovata.
	 * @return file caricato.
	 */
	public static EmergingPatternMiner carica(String nomeFile)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(nomeFile));
		EmergingPatternMiner ep = (EmergingPatternMiner) in.readObject();
		in.close();
		return ep;
	}

}
