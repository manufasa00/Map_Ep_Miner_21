package mining;

import java.io.Serializable;

import data.ContinuousAttribute;

/**
 * 
 * Ruolo: estende la classe astratta Item e modella la coppia "Attributo
 * continuo - Intervallo di valori" (Temperature in [10;30.31[).
 * 
 * @author manue,ufrack.
 *
 */
class ContinuousItem extends Item implements Serializable {

	/**
	 * Chiama il costruttore della superclasse passandogli come argomenti attribute
	 * e value.
	 * 
	 * @param attribute attributo continuo
	 * @param value     intervallo.
	 */
	public ContinuousItem(ContinuousAttribute attribute, Interval value) {
		super(attribute, value);
	}

	/**
	 * Verifica che il parametro value rappresenti un numero reale incluso tra gli
	 * estremi dell’intervallo associato allo item in oggetto richiamando il metodo
	 * checkValueInclusion(_) della classe Interval.
	 * 
	 * @param value valore che al run time sarà di tipo Float.
	 * 
	 */
	boolean checkItemCondition(Object value) {
		Interval in = (Interval) this.getValue();
		return in.checkValueInclusion((float) value);
	}

	/**
	 * Avvalora la stringa che rappresenta lo stato dell’oggetto (per esempio,
	 * Temperatura in [10;20.4[) e ne restituisce il riferimento.
	 * 
	 * @return stringa che rappresenta lo stato dell’oggetto nella forma "nome
	 *         attributo in [inf , sup[".
	 */
	public String toString() {
		String output = "(";
		Interval in = (Interval) this.getValue();
		output += this.getAttribute().getName() + " in [" + Float.toString(in.getInf()) + ","
				+ Float.toString(in.getSup()) + "[" + ")";

		return output;
	}

}
