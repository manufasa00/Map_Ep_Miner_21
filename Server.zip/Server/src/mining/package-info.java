/**
 * Contiene la collezione di classi che permettono di calcolare le scoperte.
 */
package mining;