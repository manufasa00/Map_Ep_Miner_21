package mining;

import java.io.Serializable;

import data.DiscreteAttribute;

/**
 * 
 * Ruolo: estende la classe Item e rappresenta la coppia "Attributo discreto -
 * valore discreto" (Outlook = 'Sunny').
 * 
 * @author manue,ufrack.
 *
 */
class DiscreteItem extends Item implements Serializable {

	/**
	 * Invoca il costruttore della classe madre per avvalora i membri.
	 * 
	 * @param attribute attributo discreto
	 * @param value     un suo valore.
	 */
	DiscreteItem(DiscreteAttribute attribute, String value) {
		super(attribute, value);
	}

	/**
	 * Verifica che il membro value sia uguale (nello stato) all’argomento passato
	 * come parametro della funzione.
	 * 
	 * @param value value dichiarato di tipo Object (in realtà sarà di tipo String).
	 * 
	 */
	boolean checkItemCondition(Object value) {
		return getValue().equals(value);
	}

}
