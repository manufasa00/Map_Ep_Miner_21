package mining;

import java.io.Serializable;

/**
 * 
 * Ruolo: estende FrequenPattern e modella un pattern emergente.
 * 
 * @author manue,ufrack.
 *
 */
class EmergingPattern extends FrequentPattern implements Serializable {
	/** Grow rate del pattern. */
	private float growrate;

	/**
	 * Chiama il costruttore della superclasse passandogli fp e inizializza il
	 * membro growrate con l’argomento del costruttore.
	 * 
	 * @param fp       pattern
	 * @param growrate grow rate del pattern.
	 */
	EmergingPattern(FrequentPattern fp, float growrate) {
		super(fp);
		this.growrate = growrate;
	}

	/**
	 * Restituisce il valore del membro growrate.
	 * 
	 * @return grow rate del pattern.
	 */
	float getGrowRate() {
		return growrate;
	}

	/**
	 * Si crea e restituisce la stringa che rappresenta il pattern,il suo supporto e
	 * il suo growrate facendo uso del toString() ereditato da FrequentPattern.
	 * 
	 * @return stringa contenente il pattern emergente nella forma “pattern
	 *         [supporto] [growrate]".
	 */
	public String toString() {
		String output = super.toString();
		output = output + "[" + this.getGrowRate() + "]";
		return output;
	}

}
