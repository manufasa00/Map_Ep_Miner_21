package mining;

import java.util.Comparator;

/**
 * 
 * Ruolo: classe comparatore per l'implementazione dell'interfaccia generica
 * Comparator.
 * 
 * @author manue,ufrack.
 *
 */
class ComparatorGrowRate implements Comparator<EmergingPattern> {

	/**
	 * Effettua il confronto tra due emerging pattern rispetto al grow rate.
	 * 
	 */
	public int compare(EmergingPattern o1, EmergingPattern o2) {
		return (o1.getGrowRate() < o2.getGrowRate()) ? -1 : (o1.getGrowRate() == o2.getGrowRate() ? 0 : 1);
	}

}
