package mining;

import java.io.Serializable;

import data.Attribute;

/**
 * 
 * Ruolo: modella un generico item (coppia attributo-valore, per esempio Outlook
 * = 'Sunny').
 * 
 * @author manue,ufrack.
 *
 */
public abstract class Item implements Serializable {
	/**
	 * attributo dell'elemento da modellare.
	 */
	private Attribute attribute;
	/**
	 * valore dell'elemento da modellare.
	 */
	private Object value;

	/**
	 * Inizializza i valori dei membri attributi con i parametri passati come
	 * argomento al costruttore.
	 * 
	 * @param attribute riferimento per inizializzare il campo attribute
	 * @param value     riferimento per inizializzare il campo value.
	 */
	Item(Attribute attribute, Object value) {
		this.attribute = attribute;
		this.value = value;
	}

	/**
	 * Restituisce il membro attribute.
	 * 
	 * @return attributo membro dell'item.
	 */
	Attribute getAttribute() {
		return attribute;
	}

	/**
	 * Restituisce il membro value.
	 * 
	 * @return valore coinvolto nell'item.
	 */
	Object getValue() {
		return value;
	}

	/**
	 * metodo da realizzare nelle sottoclassi.
	 * 
	 * @param value valore su cui verificare il controllo.
	 * 
	 * @return booleano che indica se il value è corretto.
	 */
	abstract boolean checkItemCondition(Object value);

	/**
	 * Restituisce una stringa nella forma attribute = value.
	 */
	public String toString() {
		String output = "(" + attribute.getName() + "=" + value.toString() + ")";
		return output;
	}

}
