package mining;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;

import data.ContinuousAttribute;
import data.Data;
import data.DiscreteAttribute;

/**
 * 
 * Ruolo: appresenta un itemset (o pattern) frequente.
 * 
 * @author manue,ufrack.
 *
 */
class FrequentPattern implements Iterable<Item>, Comparable<FrequentPattern>, Serializable {
	/** Membro fp rappresentato come una LinkedList di Item. */
	private LinkedList<Item> fp;
	/** Supporto del pattern. */
	private float support;

	/**
	 * Costruttore che alloca fp come una LinkedList di Item.
	 */
	FrequentPattern() {
		fp = new LinkedList<Item>();
	}

	/**
	 * Costruttore che alloca fp e support come copia del frequent pattern FP
	 * passato.
	 * 
	 * @param FP FrequentPattern da copiare.
	 */
	FrequentPattern(FrequentPattern FP) {
		Iterator<Item> e = FP.iterator();
		fp = new LinkedList<Item>();
		while (e.hasNext()) {
			addItem(e.next());
		}

		support = FP.getSupport();
	}

	/**
	 * Si inserisce nell'ultima posizione l’argomento della procedura.
	 * 
	 * @param item oggetto Item da aggiungere al pattern.
	 */
	void addItem(Item item) {
		fp.addLast(item);
	}

	/**
	 * Si scandisce fp al fine di concatenare in una stringa la rappresentazione
	 * degli item; alla fine si concatena il supporto.
	 * 
	 * @return stringa rappresentante lo item set e il suo supporto.
	 * 
	 */
	public String toString() {
		String value = "";
		Item temp;
		Iterator<Item> e = fp.iterator();
		while (e.hasNext()) {
			temp = e.next();
			if (e.hasNext()) {
				value += temp + " AND ";
			}
		}

		if (fp.size() > 0) {
			value += fp.get(fp.size() - 1);
			value += "[" + support + "]";
		}

		return value;
	}

	/**
	 * Calcola il supporto del pattern rappresentato dall'oggetto this rispetto al
	 * dataset data passato come argomento.
	 * 
	 * @param data valore di supporto del pattern nel dataset data.
	 * 
	 * @return valore del supporto.
	 * 
	 */
	float computeSupport(Data data) {
		int suppCount = 0;
		// indice esempio
		for (int i = 0; i < data.getNumberOfExamples(); i++) {
			// indice item
			boolean isSupporting = true;
			for (int j = 0; j < this.getPatternLength(); j++) {
				// DiscreteItem
				if (this.getItem(j) instanceof DiscreteItem) {
					DiscreteItem item = (DiscreteItem) this.getItem(j);
					DiscreteAttribute attribute = (DiscreteAttribute) item.getAttribute();
					// Extract the example value
					Object valueInExample = data.getAttributeValue(i, attribute.getIndex());
					if (!item.checkItemCondition(valueInExample)) {
						isSupporting = false;
						break; // the ith example does not satisfy fp
					}

				} else { // if(this.getItem(j) instanceof ContinuousItem)
					ContinuousItem item = (ContinuousItem) this.getItem(j);
					ContinuousAttribute attribute = (ContinuousAttribute) item.getAttribute();
					// Extract the example value
					Object valueInExample = data.getAttributeValue(i, attribute.getIndex());
					if (!item.checkItemCondition(valueInExample)) {
						isSupporting = false;
						break; // the ith example does not satisfy fp
					}
				}

			}
			if (isSupporting)
				suppCount++;
		}
		return ((float) suppCount) / (data.getNumberOfExamples());

	}

	/**
	 * Restituisce l'item in posizione index di fp.
	 * 
	 * @param index posizione in fp.
	 * @return Item che occupa la posizione indicata in fp.
	 * 
	 */
	Item getItem(int index) {
		return fp.get(index);
	}

	/**
	 * Restituisce il membro support.
	 * 
	 * @return valore di supporto del pattern.
	 */
	float getSupport() {
		return support;
	}

	/**
	 * Restituisce la dimensione (lunghezza) di fp.
	 * 
	 * @return lunghezza del pattern.
	 */
	int getPatternLength() {
		return fp.size();
	}

	/**
	 * Assegna al membro support il parametro della procedura.
	 * 
	 * @param support valore di supporto del pattern.
	 */
	void setSupport(float support) {
		this.support = support;
	}

	/**
	 * confronto tra pattern rispetto al supporto.
	 */
	public int compareTo(FrequentPattern o) {
		return (o.getSupport() < support ? 1 : (o.getSupport() == support ? 0 : -1));
	}

	@Override
	public Iterator<Item> iterator() {
		Iterator<Item> iItem = fp.iterator();
		return iItem;
	}

}
