package mining;

/**
 * 
 * Ruolo: modella l’eccezione che occorre qualora il pattern corrente non
 * soddisfa la condizione di minimo grow rate.
 * 
 * @author manue,ufrack.
 *
 */
class EmergingPatternException extends Exception {
	/**
	 * Costruttore dell'eccezione per un EmergingPattern.
	 * 
	 * @param msg messaggio da stampare a video.
	 */
	public EmergingPatternException(String msg) {
		super(msg);
	}

}
