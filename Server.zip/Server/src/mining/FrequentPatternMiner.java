package mining;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

import data.Attribute;
import data.ContinuousAttribute;
import data.Data;
import data.DiscreteAttribute;
import data.EmptySetException;
import utility.EmptyQueueException;
import utility.Queue;

/**
 * 
 * Ruolo: include i metodi per la scoperta di pattern frequenti con Algoritmo
 * APRIORI.
 * 
 * @author manue,ufrack.
 *
 */
public class FrequentPatternMiner implements Iterable<FrequentPattern>, Serializable {
	/**
	 * Lista dei pattern frequenti rappresentata come una LinkedList di
	 * FrequentPattern.
	 */
	private LinkedList<FrequentPattern> outputFP = new LinkedList<FrequentPattern>();

	/**
	 * Costruttore che genera tutti i pattern k=1 frequenti e per ognuno di questi
	 * genera quelli con k>1 richiamando expandFrequentPatterns(). I pattern sono
	 * memorizzati nel membro outputFP.
	 * 
	 * @param data   insieme delle transazioni
	 * @param minSup minimo supporto.
	 * @throws EmptySetException   possibili errori di insieme vuoto
	 * @throws EmptyQueueException possibili errori di coda vuota.
	 */
	public FrequentPatternMiner(Data data, float minSup) throws EmptySetException, EmptyQueueException {
		Queue<FrequentPattern> fpQueue = new Queue<FrequentPattern>();

		for (int i = 0; i < data.getNumberOfAttributes(); i++) {
			Attribute currentAttribute = data.getAttribute(i);
			if (currentAttribute instanceof DiscreteAttribute) {
				for (int j = 0; j < ((DiscreteAttribute) currentAttribute).getNumberOfDistinctValues(); j++) {
					DiscreteItem item = new DiscreteItem((DiscreteAttribute) currentAttribute,
							((DiscreteAttribute) currentAttribute).getValue(j));
					FrequentPattern fp = new FrequentPattern();
					fp.addItem(item);
					fp.setSupport(fp.computeSupport(data));
					if (fp.getSupport() >= minSup) { // 1-FP CANDIDATE
						fpQueue.enqueue(fp);
						// System.out.println(fp);
						outputFP.addLast(fp);
					}
				}

			}
			if (currentAttribute instanceof ContinuousAttribute) {
				Iterator<Float> it = ((ContinuousAttribute) currentAttribute).iterator();
				while (it.hasNext()) {
					ContinuousItem item = new ContinuousItem((ContinuousAttribute) currentAttribute,
							new Interval(it.next(), it.next()));
					FrequentPattern fp = new FrequentPattern();
					fp.addItem(item);
					fp.setSupport(fp.computeSupport(data));
					if (fp.getSupport() >= minSup) { // 1-FP CANDIDATE
						fpQueue.enqueue(fp);
						// System.out.println(fp);
						outputFP.addLast(fp);
					}

				}

			}

		}

		outputFP = expandFrequentPatterns(data, minSup, fpQueue, outputFP);
		sort();

	}

	/**
	 * Finché fpQueue contiene elementi, si estrae un elemento dalla coda fpQueue,
	 * si generano i raffinamenti per questo (aggiungendo un nuovo item non
	 * incluso). Per ogni raffinamento si verifica se e' frequente e, in caso
	 * affermativo, lo si aggiunge sia ad fpQueue sia ad outputFP.
	 * 
	 * @param data     l’insieme delle transazioni
	 * @param minSup   minimo supporto
	 * @param fpQueue  coda contente i pattern da valutare
	 * @param outputFP lista dei pattern frequenti già estratti.
	 * @return lista linkata popolata con pattern frequenti a k>1.
	 */
	private LinkedList<FrequentPattern> expandFrequentPatterns(Data data, float minSup, Queue<FrequentPattern> fpQueue,
			LinkedList<FrequentPattern> outputFP) {
		while (!fpQueue.isEmpty()) {
			FrequentPattern fp = fpQueue.first(); // fp to be refined
			fpQueue.dequeue();
			for (int i = 0; i < data.getNumberOfAttributes(); i++) {
				boolean found = false;
				for (int j = 0; j < fp.getPatternLength(); j++) // the new item should involve an attribute different
																// form attributes already involved into the items of fp
					if (fp.getItem(j).getAttribute().equals(data.getAttribute(i))) {
						found = true;
						break;
					}
				if (!found) // data.getAttribute(i) is not involve into an item of fp
				{
					if (data.getAttribute(i) instanceof DiscreteAttribute) {

						for (int j = 0; j < ((DiscreteAttribute) data.getAttribute(i))
								.getNumberOfDistinctValues(); j++) {
							DiscreteItem item = new DiscreteItem((DiscreteAttribute) data.getAttribute(i),
									((DiscreteAttribute) (data.getAttribute(i))).getValue(j));
							FrequentPattern newFP = refineFrequentPattern(fp, item); // generate refinement
							newFP.setSupport(newFP.computeSupport(data));
							if (newFP.getSupport() >= minSup) {
								fpQueue.enqueue(newFP);
								// System.out.println(newFP);
								outputFP.add(newFP);
							}
						}
					}
					if (data.getAttribute(i) instanceof ContinuousAttribute) {
						Iterator<Float> it = ((ContinuousAttribute) data.getAttribute(i)).iterator();

						while (it.hasNext()) {
							ContinuousItem item = new ContinuousItem((ContinuousAttribute) data.getAttribute(i),
									new Interval(it.next(), it.next()));
							FrequentPattern newFP = refineFrequentPattern(fp, item); // generate refinement
							newFP.setSupport(newFP.computeSupport(data));
							if (newFP.getSupport() >= minSup) {
								fpQueue.enqueue(newFP);
								// System.out.println(newFP);
								outputFP.add(newFP);
							}

						}

					}
				}

			}
		}
		return outputFP;
	}

	/**
	 * Crea un nuovo pattern a cui aggiunge tutti gli item di FP e il parametro
	 * item.
	 * 
	 * @param FP   pattern da raffinare,
	 * @param item item da aggiungere ad FP.
	 * @return nuovo pattern ottenuto per effetto del raffinamento.
	 */
	FrequentPattern refineFrequentPattern(FrequentPattern FP, Item item) {
		FrequentPattern updatefp = new FrequentPattern(FP);
		updatefp.addItem(item);

		return updatefp;

	}

	/**
	 * Restituisce il membro outputFP.
	 * 
	 * @return lista di FrequentPattern.
	 */
	LinkedList<FrequentPattern> getFP() {
		return outputFP;
	}

	/**
	 * Scandisce outputFp al fine di concatenare in un'unica stringa i pattern
	 * frequenti letti.
	 * 
	 * @return Stringa rappresentante il valore di outputFP.
	 * 
	 */
	public String toString() {
		String value = "Frequent patterns\n";
		int i = 0;
		Iterator<FrequentPattern> e = outputFP.iterator();
		while (e.hasNext()) {
			value += Integer.toString(i + 1) + ": " + e.next() + "\n";
			i++;
		}
		return value;
	}

	@Override
	public Iterator<FrequentPattern> iterator() {
		Iterator<FrequentPattern> ifp = outputFP.iterator();
		return ifp;
	}

	/**
	 * si occupa di ordinare outputFP usando il comparatore associato alla classe
	 * FrequentPattern.
	 */
	private void sort() {
		Collections.sort(outputFP);

	}

	/**
	 * si occupa di serializzare l’oggetto riferito da this nel file il cui nome e'
	 * passato come parametro.
	 * 
	 * @param nomeFile nome del file in cui avviene la serializzazione.
	 * @throws FileNotFoundException possibili errori di file non trovato
	 * @throws IOException           possibili errori di Input\Output.
	 */
	public void salva(String nomeFile) throws FileNotFoundException, IOException {
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nomeFile));
		out.writeObject(this);
		out.close();

	}

	/**
	 * si occupa di leggere e restituire l’oggetto come e' memorizzato nel file il
	 * cui nome e' passato come parametro.
	 * 
	 * @param nomeFile nome del file da cui viene caricato l'oggetto.
	 * @throws FileNotFoundException  possibili errori di file non trovato.
	 * @throws IOException            possibili errori di Input/Output
	 * @throws ClassNotFoundException possibili errori di classe non trovata.
	 * @return file caricato.
	 */
	public static FrequentPatternMiner carica(String nomeFile)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(nomeFile));
		FrequentPatternMiner fp = (FrequentPatternMiner) in.readObject();
		in.close();
		return fp;
	}
}
