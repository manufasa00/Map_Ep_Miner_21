/**
 * Contiene il codice Main del Client.
 */
package client;