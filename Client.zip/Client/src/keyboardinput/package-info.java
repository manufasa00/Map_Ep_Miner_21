/**
 * Contiene la classe per l'Input/Output in modo da interagire con l'utente per
 * acquisire da tastiera valori validi.
 */
package keyboardinput;